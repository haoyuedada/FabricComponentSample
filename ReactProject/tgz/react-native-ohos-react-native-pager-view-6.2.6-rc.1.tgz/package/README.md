# @react-native-ohos/react-native-pager-view

This project is based on [react-native-pager-view@7.0.2](https://github.com/callstack/react-native-pager-view/tree/v7.0.2)

## Documentation

[中文](https://https://gitcode.com/OpenHarmony-RN/usage-docs/blob/master/zh-cn/react-native-pager-view.md)

[English](https://https://gitcode.com/OpenHarmony-RN/usage-docs/blob/master/en/react-native-pager-view.md)


## License

This library is licensed under [The MIT License (MIT)](https://github.com/react-native-oh-library/react-native-pager-view/blob/sig/LICENSE).

