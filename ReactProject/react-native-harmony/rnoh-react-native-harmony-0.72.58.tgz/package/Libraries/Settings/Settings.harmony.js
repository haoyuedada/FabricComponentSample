import SettingsNativeForHarmony from "./SettingsNativeForHarmony";
const Settings = {
  get(key: string): any {
    let res = SettingsNativeForHarmony.get(key)
    try {
      res = JSON.parse(res)
    } catch (error) {
      console.error("无需解析", error)
    }
    return res
  },

  set(settings: Object) {
    try {
      let key = Object.keys(settings)[0]
      let value = Object.values(settings)[0]
      if(typeof value == 'object') value = JSON.stringify(value)
      SettingsNativeForHarmony?.set(key,value);
    } catch (error) {
      console.error("error")
    }
  },

  clearWatch(watchId: number) {
    // console.log("clearWatch", clearWatch);
    return SettingsNativeForHarmony?.clearWatch(watchId);
  },
};
module.exports = Settings;
