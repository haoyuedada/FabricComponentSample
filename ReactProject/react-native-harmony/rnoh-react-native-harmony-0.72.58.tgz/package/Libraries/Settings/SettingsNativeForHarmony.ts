import type { TurboModule } from "react-native/Libraries/TurboModule/RCTExport";

import * as TurboModuleRegistry from "react-native/Libraries/TurboModule/TurboModuleRegistry";

export interface Spec extends TurboModule {
  new();
  get: (key: string) => any;
  set: (settings: Object) => void;
  clearWatch: (watchId: number) => void;
}

export default TurboModuleRegistry.get<Spec>("SettingsManager");