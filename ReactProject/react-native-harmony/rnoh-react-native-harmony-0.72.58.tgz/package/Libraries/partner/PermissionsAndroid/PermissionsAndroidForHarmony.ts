import type { TurboModule } from "react-native/Libraries/TurboModule/RCTExport";

import * as TurboModuleRegistry from "react-native/Libraries/TurboModule/TurboModuleRegistry";


export interface Rationale {
  title: string;
  message: string;
  buttonPositive: string;
  buttonNegative?: string | undefined;
  buttonNeutral?: string | undefined;
}

export type Permission =
  | 'android.permission.READ_CALENDAR'
  | 'android.permission.WRITE_CALENDAR'
  | 'android.permission.CAMERA'
  | 'android.permission.READ_CONTACTS'
  | 'android.permission.WRITE_CONTACTS'
  | 'android.permission.GET_ACCOUNTS'
  | 'android.permission.ACCESS_BACKGROUND_LOCATION'
  | 'android.permission.ACCESS_FINE_LOCATION'
  | 'android.permission.ACCESS_COARSE_LOCATION'
  | 'android.permission.RECORD_AUDIO'
  | 'android.permission.READ_PHONE_STATE'
  | 'android.permission.CALL_PHONE'
  | 'android.permission.READ_CALL_LOG'
  | 'android.permission.WRITE_CALL_LOG'
  | 'com.android.voicemail.permission.ADD_VOICEMAIL'
  | 'com.android.voicemail.permission.READ_VOICEMAIL'
  | 'com.android.voicemail.permission.WRITE_VOICEMAIL'
  | 'android.permission.USE_SIP'
  | 'android.permission.PROCESS_OUTGOING_CALLS'
  | 'android.permission.BODY_SENSORS'
  | 'android.permission.SEND_SMS'
  | 'android.permission.RECEIVE_SMS'
  | 'android.permission.READ_SMS'
  | 'android.permission.RECEIVE_WAP_PUSH'
  | 'android.permission.RECEIVE_MMS'
  | 'android.permission.READ_EXTERNAL_STORAGE'
  | 'android.permission.WRITE_EXTERNAL_STORAGE'
  

export type PermissionStatus = 'granted' | 'denied' | 'never_ask_again';


export interface Spec extends TurboModule {

   /**
   * A list of permission results that are returned
   */
  RESULTS: {[key: string]: PermissionStatus};
   /**
    * A list of specified "dangerous" permissions that require prompting the user
    */
  PERMISSIONS: {[key: string]: Permission};

  new ();

  check: (permission: Permission) => Promise<boolean>;

  request: (permission: Permission, rationale?: Rationale) => Promise<PermissionStatus>;

  requestMultiple: (permission: Array<Permission>) => Promise<{[key in Permission]: PermissionStatus}>;
}

export default TurboModuleRegistry.get<Spec>("PermissionsAndroid");
