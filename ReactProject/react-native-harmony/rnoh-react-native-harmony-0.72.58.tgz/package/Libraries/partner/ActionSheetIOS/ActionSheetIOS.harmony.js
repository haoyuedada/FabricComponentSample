/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @flow
 * @format
 */

import Platform from "react-native/Libraries/Utilities/Platform";
import NativeActionSheetManager from "react-native/Libraries/ActionSheetIOS/NativeActionSheetManager";
/**
 * Display action sheets and share sheets on iOS.
 *
 * See https://reactnative.dev/docs/actionsheetios
 */
const ActionSheetIOS = {
  async  showActionSheetWithOptions(
    options: Object,
    callback: (buttonIndex: number) => void
  ) {
    try {
      const res=  await NativeActionSheetManager.showActionSheetWithOptions(options, callback);
      callback(res);
      console.log("res",res)      
    } catch (error) {
      console.error(error)      
    }
  },

  /**
   * Display the iOS share sheet. The `options` object should contain
   * one or both of `message` and `url` and can additionally have
   * a `subject` or `excludedActivityTypes`:
   *
   * - `url` (string) - a URL to share
   * - `message` (string) - a message to share
   * - `subject` (string) - a subject for the message
   * - `excludedActivityTypes` (array) - the activities to exclude from
   *   the ActionSheet
   * - `tintColor` (color) - tint color of the buttons
   *
   * The 'failureCallback' function takes one parameter, an error object.
   * The only property defined on this object is an optional `stack` property
   * of type `string`.
   *
   * The 'successCallback' function takes two parameters:
   *
   * - a boolean value signifying success or failure
   * - a string that, in the case of success, indicates the method of sharing
   *
   * See https://reactnative.dev/docs/actionsheetios#showshareactionsheetwithoptions
   */
  async showShareActionSheetWithOptions(
    options: Object,
    failureCallback: Function,
    successCallback: Function
  ) {
    try {
      const res= await NativeActionSheetManager.showShareActionSheetWithOptions(
        options,
      );
      console.log("分享结果", res)
      successCallback();
    } catch (error) {
      console.error(error)
      failureCallback();
    }
   
  },

  dismissActionSheet: () => {
    console.log("dismissActionSheet");
  },
};

module.exports = ActionSheetIOS;

export default ActionSheetIOS