import React from "react";
import ActionSheetIOS from "./ActionSheetIOS.harmony";

class ActionSheetView extends React.Component {
  static showShareActionSheetWithOptions(opt, fail, success) {
    console.log("调用了");
    ActionSheetIOS.showShareActionSheetWithOptions(opt, fail, success);
  }
}

