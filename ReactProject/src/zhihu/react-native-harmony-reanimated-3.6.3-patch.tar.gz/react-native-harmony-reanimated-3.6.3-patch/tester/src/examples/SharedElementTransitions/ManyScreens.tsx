import * as React from 'react';
import {View, Button, StyleSheet} from 'react-native';
import {ParamListBase} from '@react-navigation/native';
import {createStackNavigator, StackScreenProps} from '@react-navigation/stack';
import Animated from 'react-native-reanimated';

const Stack = createStackNavigator();

function Screen1({navigation}: StackScreenProps<ParamListBase>) {
  return (
    <View style={styles.flexOne}>
      <Animated.View style={styles.redBox} sharedTransitionTag="tag1" />
      <Button title="Screen2" onPress={() => navigation.navigate('Screen2')} />
      <Button title="Screen3" onPress={() => navigation.navigate('Screen3')} />
    </View>
  );
}

function Screen2({navigation}: StackScreenProps<ParamListBase>) {
  return (
    <View style={styles.container}>
      <Animated.View style={styles.greenBox} sharedTransitionTag="tag1" />
      <Button title="Screen1" onPress={() => navigation.navigate('Screen1')} />
      <Button title="Screen3" onPress={() => navigation.navigate('Screen3')} />
    </View>
  );
}

function Screen3({navigation}: StackScreenProps<ParamListBase>) {
  return (
    <View style={styles.flexOne}>
      <Animated.View style={styles.blueBox} sharedTransitionTag="tag1" />
      <Button title="Screen1" onPress={() => navigation.navigate('Screen1')} />
      <Button title="Screen2" onPress={() => navigation.navigate('Screen2')} />
    </View>
  );
}

export default function ManyScreensExample() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Screen1"
        component={Screen1}
        options={{headerShown: true}}
      />
      <Stack.Screen
        name="Screen2"
        component={Screen2}
        options={{headerShown: true}}
      />
      <Stack.Screen
        name="Screen3"
        component={Screen3}
        options={{headerShown: true}}
      />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  flexOne: {
    flex: 1,
  },
  container: {
    flex: 1,
    marginTop: 50,
  },
  redBox: {
    width: 150,
    height: 150,
    backgroundColor: 'red',
  },
  greenBox: {
    width: 100,
    height: 100,
    backgroundColor: 'green',
  },
  blueBox: {
    width: 100,
    height: 100,
    backgroundColor: 'blue',
  },
});
