import * as Animated from 'react-native-reanimated/src/Animated';
export * from './reanimated2/NativeReanimated/NativeReanimated';
export * from 'react-native-reanimated/src/reanimated2';
export default Animated;
//# sourceMappingURL=index.d.ts.map