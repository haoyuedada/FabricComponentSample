# @react-native-ohos/native-stack
This project is based on [@react-navigation/native-stack](https://github.com/react-navigation/react-navigation/tree/main/packages/native-stack)
## Documentation
[中文](https://gitcode.com/OpenHarmony-RN/usage-docs/blob/master/zh-cn/react-navigation-native-stack.md)

[English](https://gitcode.com/OpenHarmony-RN/usage-docs/blob/master/en/react-navigation-native-stack.md)

## License
This library is licensed under [The MIT License (MIT)](https://opensource.org/license/MIT).
