import React from 'react';
import {
    View,
    Text,
    requireNativeComponent,
    StyleSheet, ScrollView, Platform
} from 'react-native';
import PropTypes from 'prop-types';
import RNSmartRefresh from "./RNSmartRefresh/RNSmartRefresh"
import RNSmartRefreshHeader from "./RNSmartRefresh/RNSmartRefreshHeader"

import RefreshAnimateView from "./RNSmartRefreshView/RNSmartRefreshAnimateView";
import RefreshNormalView from "./RNSmartRefreshView/RNSmartRefreshNormalView";

export class SmartRefresh extends React.PureComponent {
    constructor(props) {
        super(props);
    }
    static propTypes = {
        style: PropTypes.object,
        onRefresh: PropTypes.func,
        onChangeState: PropTypes.func,
        onChangeOffset: PropTypes.func,
        refreshing: PropTypes.bool,
    }
    static defaultProps = {
        style: { position: 'absolute', left: 0, top: 0, right: 0 },
        onRefresh: () => { },
        onChangeOffset: () => { },
        refreshing: false,
    }
    render() {
        const { children } = this.props;
        return (
            <RNSmartRefresh
                {...this.props}
            >
                {children}
            </RNSmartRefresh>
        );

    }
}
export class SmartRefreshHeader extends React.PureComponent {
    ref = React.createRef();
    constructor(props) {
        super(props);
    }
    render() {
        const { children, style } = this.props;
        return (
            <RNSmartRefreshHeader
                ref={this.ref}
            >
                <View
                    style={StyleSheet.compose({ height: 100 }, style)}
                >
                    {children}
                </View>
            </RNSmartRefreshHeader>
        );
    }
}

export {
    RefreshNormalView,
    RefreshAnimateView
}
const styles = StyleSheet.create({
    container: {
        flex: 1
    }
})