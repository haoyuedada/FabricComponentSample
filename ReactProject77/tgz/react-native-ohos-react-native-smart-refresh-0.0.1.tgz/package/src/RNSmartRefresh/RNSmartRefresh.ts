import { HostComponent, ScrollViewProps, ViewProps } from 'react-native';
import {
    DirectEventHandler,
    Int32,
    UnsafeObject,
    BubblingEventHandler,
} from 'react-native/Libraries/Types/CodegenTypes';
import codegenNativeComponent from 'react-native/Libraries/Utilities/codegenNativeComponent';
import codegenNativeCommands from 'react-native/Libraries/Utilities/codegenNativeCommands';


interface refreshEvent { }

interface changeOffsetEvent { }

interface changeStateEvent { }

export interface RNSmartRefreshProps extends ViewProps {
    refreshing?: boolean,
    onRefresh?: DirectEventHandler<refreshEvent>,
    onChangeOffset?: DirectEventHandler<changeOffsetEvent>,
    onChangeState?: DirectEventHandler<changeStateEvent>,
}

export type RNSmartRefreshComponentType = HostComponent<RNSmartRefreshProps>;

export interface RNSmartRefreshCommands { }

export const Commands: RNSmartRefreshCommands = codegenNativeCommands<RNSmartRefreshCommands>({
    supportedCommands: [],
});

export default codegenNativeComponent<RNSmartRefreshProps>(
    'RNSmartRefresh',
) as HostComponent<RNSmartRefreshProps>;