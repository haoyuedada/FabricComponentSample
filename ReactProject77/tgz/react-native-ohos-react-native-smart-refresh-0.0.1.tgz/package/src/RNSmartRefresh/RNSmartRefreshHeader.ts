import { HostComponent, ViewProps } from 'react-native';
import {
  DirectEventHandler,
  Int32,
  UnsafeObject,
} from 'react-native/Libraries/Types/CodegenTypes';
import codegenNativeComponent from 'react-native/Libraries/Utilities/codegenNativeComponent';
import codegenNativeCommands from 'react-native/Libraries/Utilities/codegenNativeCommands';


export interface RNSmartRefreshHeaderProps extends ViewProps { }

export type RNSmartRefreshHeaderComponentType = HostComponent<RNSmartRefreshHeaderProps>;

export interface RNSmartRefreshHeaderCommands { }

export const Commands: RNSmartRefreshHeaderCommands = codegenNativeCommands<RNSmartRefreshHeaderCommands>({
  supportedCommands: [],
});

export default codegenNativeComponent<RNSmartRefreshHeaderProps>(
  'RNSmartRefreshHeader',
) as HostComponent<RNSmartRefreshHeaderProps>;