#include "RNOH/PackageProvider.h"
#include "generated/RNOHGeneratedPackage.h"
//#include "SmartRefreshLayoutPackage.h"
//#include "RNSmartRefreshPackage.h"
using namespace rnoh;

std::vector<std::shared_ptr<Package>> PackageProvider::getPackages(Package::Context ctx) {
    return {
        std::make_shared<RNOHGeneratedPackage>(ctx),
//        std::make_shared<RNSmartRefreshPackage>(ctx)
//        std::make_shared<SmartRefreshLayoutPackage>(ctx)
    };
}