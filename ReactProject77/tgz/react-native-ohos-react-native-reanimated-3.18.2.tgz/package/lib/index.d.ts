import Animated from 'react-native-reanimated';
export * from 'react-native-reanimated';
export default Animated;
//# sourceMappingURL=index.d.ts.map