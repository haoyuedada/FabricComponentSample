// Copyright (c) 2025 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

import { RNOHLogger, Tag, UITurboModule, UITurboModuleContext } from "@rnoh/react-native-openharmony/ts";

export class WorkletsModule extends UITurboModule {
  static NAME = "WorkletsModule"
  private logger: RNOHLogger

  constructor(ctx: UITurboModuleContext) {
    super(ctx);
    this.logger = ctx.logger.clone("WorkletsModule");
  }
}