// Copyright (c) 2025 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#pragma once

#include "RNOH/ArkTSTurboModule.h"
#include "ReanimatedModuleProxy.h"
#include "ReanimatedNodesManager.h"

namespace rnoh {
class JSI_EXPORT ReanimatedModule : public std::enable_shared_from_this<ReanimatedModule>, public ArkTSTurboModule {
public:
    ReanimatedModule(const ArkTSTurboModule::Context ctx, const std::string name);
    ~ReanimatedModule() override;
    void installTurboModule(facebook::jsi::Runtime &rt);
    void callKeyBord(double height, int status);
private:
    std::weak_ptr<reanimated::ReanimatedModuleProxy> weakNativeReanimatedModule_;
    void injectDependencies(facebook::jsi::Runtime &rt);
    std::shared_ptr<facebook::react::EventListener> eventListener;
    std::function<void(int keyboardState, int height)> keyboardEventDataUpdater_;
};
} // namespace rnoh