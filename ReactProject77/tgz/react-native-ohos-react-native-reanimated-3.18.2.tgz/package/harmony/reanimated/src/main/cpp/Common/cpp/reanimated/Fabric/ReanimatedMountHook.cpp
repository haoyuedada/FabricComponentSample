#ifdef RCT_NEW_ARCH_ENABLED

#include <glog/logging.h>
#include <reanimated/Fabric/ReanimatedCommitShadowNode.h>
#include <reanimated/Fabric/ReanimatedMountHook.h>

namespace reanimated {

ReanimatedMountHook::ReanimatedMountHook(
    const std::shared_ptr<PropsRegistry> &propsRegistry,
    const std::shared_ptr<UIManager> &uiManager)
    : propsRegistry_(propsRegistry), uiManager_(uiManager) {
  uiManager_->registerMountHook(*this);
}

ReanimatedMountHook::~ReanimatedMountHook() noexcept {
  uiManager_->unregisterMountHook(*this);
}

void ReanimatedMountHook::shadowTreeDidMount(
    const RootShadowNode::Shared &rootShadowNode,
    double) noexcept {
  auto reaShadowNode =
      std::reinterpret_pointer_cast<ReanimatedCommitShadowNode>(
          std::const_pointer_cast<RootShadowNode>(rootShadowNode));

  if (reaShadowNode->hasReanimatedMountTrait()) {
    // We mark reanimated commits with ReanimatedMountTrait. We don't want other
    // shadow nodes to use this trait, but since this rootShadowNode is Shared,
    // we don't have that guarantee. That's why we also unset this trait in the
    // commit hook. We remove it here mainly for the sake of cleanliness.
    reaShadowNode->unsetReanimatedMountTrait();
    return;
  }

  {
    auto lock = propsRegistry_->createLock();
    propsRegistry_->handleNodeRemovals(*rootShadowNode);

    // When commit from React Native has finished, we reset the skip commit flag
    // in order to allow Reanimated to commit its tree
    propsRegistry_->unpauseReanimatedCommits();
    if (!propsRegistry_->shouldCommitAfterPause()) {
      return;
    }
  }

  try {
    const auto &shadowTreeRegistry = uiManager_->getShadowTreeRegistry();
    shadowTreeRegistry.visit(
        rootShadowNode->getSurfaceId(), [=](ShadowTree const &shadowTree) {
        shadowTree.commit(
            [=](RootShadowNode const &oldRootShadowNode)
                -> RootShadowNode::Unshared {
              PropsMap propsMap;

              RootShadowNode::Unshared rootNode =
                  std::static_pointer_cast<RootShadowNode>(
                      oldRootShadowNode.ShadowNode::clone({}));

              if (rootNode) {
                auto lock = propsRegistry_->createLock();

                if (!propsRegistry_->isEmpty()) {
                  propsRegistry_->for_each([&](const ShadowNodeFamily &family,
                                               const folly::dynamic &props) {
                    propsMap[&family].emplace_back(props);
                  });

                  rootNode = cloneShadowTreeWithNewProps(oldRootShadowNode, propsMap);
                }
              }

              if (rootNode) {
                auto reaShadowNode =
                    std::reinterpret_pointer_cast<ReanimatedCommitShadowNode>(
                        rootNode);
                reaShadowNode->setReanimatedCommitTrait();
              }

              return rootNode;
            },
            {/* .enableStateReconciliation = */
             false,
             /* .mountSynchronously = */ true});
      });
  } catch (const std::exception &e) {
    LOG(ERROR) << "ReanimatedMountHook::shadowTreeDidMount error: " << e.what();
  } catch (...) {
    LOG(ERROR) << "ReanimatedMountHook::shadowTreeDidMount unknown error";
  }
}

} // namespace reanimated

#endif // RCT_NEW_ARCH_ENABLED
