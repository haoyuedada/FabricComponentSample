// Copyright (c) 2025 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

import { RNPackage, UITurboModuleContext, TurboModulesFactory } from "@rnoh/react-native-openharmony/ts";
import type { UITurboModule } from "@rnoh/react-native-openharmony/ts";
import { ReanimatedModule } from './ReanimatedModule';
import { WorkletsModule } from './WorkletsModule';

class ReanimatedTurboModulesFactory extends TurboModulesFactory {
  createTurboModule(name: string): UITurboModule | null {
    if (name === ReanimatedModule.NAME) {
      return new ReanimatedModule(this.ctx);
    } else if (name === WorkletsModule.NAME) {
      return new WorkletsModule(this.ctx);
    }
    return null;
  }

  hasTurboModule(name: string): boolean {
    return name === 'ReanimatedModule' || name === 'WorkletsModule';
  }
}

export class ReanimatedPackage extends RNPackage {
  createTurboModulesFactory(ctx: UITurboModuleContext): TurboModulesFactory {
    return new ReanimatedTurboModulesFactory(ctx);
  }
}