// Copyright (c) 2025 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

import { RNOHLogger, Tag, UITurboModule, UITurboModuleContext } from "@rnoh/react-native-openharmony/ts";
import { window } from '@kit.ArkUI';
import { AnimationManager } from './AnimationManager'

export class ReanimatedModule extends UITurboModule {
  static NAME = "ReanimatedModule"
  private logger: RNOHLogger
  private keyBordHeight = 0;

  constructor(ctx:  UITurboModuleContext) {
    super(ctx);
    this.logger = ctx.logger.clone("Reanimated");
  }
  public setViewProps(tag: Tag, props: Object) {
    this.ctx.descriptorRegistry.setAnimatedRawProps(tag, props);
  }

  public async subscribeKeyBordListeners() {
    const windowInstance = await window.getLastWindow(this.ctx.uiAbilityContext);
    windowInstance.on('keyboardHeightChange', async (height) => {
      let keyBordHeight = this.ctx.getUIContext().px2vp(height);
      const animationManager = new AnimationManager();
      animationManager.setUpdateCallback((value, status) => {
        this.ctx.rnInstance.postMessageToCpp("REANIMATED_KEY_BOARD_CHANGE",
          { keyboardHeight: value, status: status.valueOf() });
      });
      animationManager.startAnimation(this.keyBordHeight, keyBordHeight, 200);
      this.keyBordHeight = keyBordHeight;
    })
  }

  public async unsubscribeKeyBordListeners() {
    const windowInstance = await window.getLastWindow(this.ctx.uiAbilityContext);
    windowInstance.off('keyboardHeightChange', (v) => {
    })
  }

  public setGestureHandlerState(handlerTag: Tag, newState: number) {
    const module = this.ctx.rnInstance.getTurboModule("RNGestureHandlerModule") as any;
    if (module && module.setGestureHandlerState) {
      module.setGestureHandlerState(handlerTag, newState);
    }
  }
}