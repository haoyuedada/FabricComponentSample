// Copyright (c) 2025 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#pragma once
#include <functional>
#include <UIScheduler.h>
#include <memory>
#include "RNOH/TaskExecutor/TaskExecutor.h"

namespace rnoh {
class ReanimatedUIScheduler : public std::enable_shared_from_this<ReanimatedUIScheduler>, public worklets::UIScheduler {
private:
    std::shared_ptr<TaskExecutor> m_taskExecutor;

public:
    ReanimatedUIScheduler(std::shared_ptr<TaskExecutor> taskExecutor);
    void scheduleOnUI(std::function<void()> job) override;
};
} // namespace rnoh