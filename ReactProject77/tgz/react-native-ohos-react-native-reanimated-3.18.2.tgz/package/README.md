# @react-native-ohos/react-native-reanimated
This project is based on [react-native-reanimated@v3.18.0](https://github.com/software-mansion/react-native-reanimated/tree/3.18.0)

## Documentation
[中文](https://gitcode.com/OpenHarmony-RN/usage-docs/blob/master/zh-cn/react-native-reanimated.md)

[English](https://gitcode.com/OpenHarmony-RN/usage-docs/blob/master/en/react-native-reanimated.md)

## License
This library is licensed under [The MIT License (MIT)](https://github.com/react-native-oh-library/react-native-harmony-reanimated/blob/sig/LICENSE).
