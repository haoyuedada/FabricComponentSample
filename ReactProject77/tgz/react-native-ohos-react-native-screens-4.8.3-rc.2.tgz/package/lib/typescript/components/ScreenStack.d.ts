import React from 'react';
import { ScreenStackProps } from 'react-native-screens/src/types';
declare function ScreenStack(props: ScreenStackProps): React.JSX.Element;
export default ScreenStack;
//# sourceMappingURL=ScreenStack.d.ts.map