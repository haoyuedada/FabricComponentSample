import React from "react";
import { ScreenContainerProps } from "react-native-screens/src/types";
declare function ScreenContainer(props: ScreenContainerProps): React.JSX.Element;
export default ScreenContainer;
//# sourceMappingURL=ScreenContainer.d.ts.map