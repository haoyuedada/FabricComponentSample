/*
 * Copyright (c) 2025 Huawei Device Co., Ltd. All rights reserved
 * Use of this source code is governed by a MIT license that can be
 * found in the LICENSE file.
 */
import Swipeable from 'react-native-gesture-handler/Swipeable';
export default Swipeable;
