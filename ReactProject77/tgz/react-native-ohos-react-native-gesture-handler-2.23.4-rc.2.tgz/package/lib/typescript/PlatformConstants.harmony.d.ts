type PlatformConstants = {
    forceTouchAvailable: boolean;
};
declare const _default: PlatformConstants;
export default _default;
//# sourceMappingURL=PlatformConstants.harmony.d.ts.map