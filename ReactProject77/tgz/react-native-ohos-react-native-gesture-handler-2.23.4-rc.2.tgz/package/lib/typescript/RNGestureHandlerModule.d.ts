declare const RNGestureHandlerModule: import("../src/specs/NativeRNGestureHandlerModule").Spec;
export default RNGestureHandlerModule;
//# sourceMappingURL=RNGestureHandlerModule.d.ts.map