/*
 * Copyright (c) 2025 Huawei Device Co., Ltd. All rights reserved
 * Use of this source code is governed by a MIT license that can be
 * found in the LICENSE file.
 */
import NativeRNGestureHandlerModule from '../src/specs/NativeRNGestureHandlerModule';

const RNGestureHandlerModule = NativeRNGestureHandlerModule;

export default RNGestureHandlerModule;