export { type SwipeableProps, type SwipeableMethods, SwipeDirection, } from 'react-native-gesture-handler/src/components/ReanimatedSwipeable/ReanimatedSwipeableProps';
export { default } from './ReanimatedSwipeable';
//# sourceMappingURL=index.d.ts.map