import React from 'react';
import { PressableProps } from 'react-native-gesture-handler/src/components/Pressable/PressableProps';
declare const Pressable: (props: PressableProps) => React.JSX.Element;
export default Pressable;
//# sourceMappingURL=Pressable.d.ts.map