import { ForwardedRef } from 'react';
import { SwipeableProps, SwipeableMethods } from 'react-native-gesture-handler/src/components/ReanimatedSwipeable/ReanimatedSwipeableProps';
declare const Swipeable: (props: SwipeableProps) => import("react").JSX.Element;
export default Swipeable;
export type SwipeableRef = ForwardedRef<SwipeableMethods>;
//# sourceMappingURL=ReanimatedSwipeable.d.ts.map