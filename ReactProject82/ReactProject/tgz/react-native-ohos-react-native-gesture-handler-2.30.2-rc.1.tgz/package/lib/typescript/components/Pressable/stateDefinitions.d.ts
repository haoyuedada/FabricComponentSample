import { PressableEvent } from 'react-native-gesture-handler/src/components/Pressable/PressableProps';
import { StateDefinition } from 'react-native-gesture-handler/src/components/Pressable/StateMachine';
export declare enum StateMachineEvent {
    NATIVE_BEGIN = "nativeBegin",
    NATIVE_START = "nativeStart",
    FINALIZE = "finalize",
    LONG_PRESS_TOUCHES_DOWN = "longPressTouchesDown",
    CANCEL = "cancel"
}
export declare function getStatesConfig(handlePressIn: (event: PressableEvent) => void, handlePressOut: (event: PressableEvent) => void): StateDefinition[];
//# sourceMappingURL=stateDefinitions.d.ts.map