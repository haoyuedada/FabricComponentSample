/*
 * Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
 * Use of this source code is governed by a MIT license that can be
 * found in the LICENSE file.
 */
import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { GestureObjects as Gesture } from 'react-native-gesture-handler/src/handlers/gestures/gestureObjects';
import { GestureDetector } from 'react-native-gesture-handler/src/handlers/gestures/GestureDetector';
import {
  PressableEvent,
  PressableProps,
  PressableDimensions,
} from 'react-native-gesture-handler/src/components/Pressable/PressableProps';
import {
  Insets,
  LayoutChangeEvent,
  Platform,
  StyleProp,
  ViewStyle,
  processColor,
} from 'react-native';
import NativeButton from 'react-native-gesture-handler/src/components/GestureHandlerButton';
import {
  // gestureToPressableEvent,
  addInsets,
  numberAsInset,
  gestureTouchToPressableEvent,
  isTouchWithinInset,
} from 'react-native-gesture-handler/src/components/Pressable/utils';
import { PressabilityDebugView } from 'react-native-gesture-handler/src/handlers/PressabilityDebugView';
import { INT32_MAX, isFabric, isTestEnv } from 'react-native-gesture-handler/src/utils';
import {
  applyRelationProp,
  RelationPropName,
  RelationPropType,
} from 'react-native-gesture-handler/src/components/utils';
import { getStatesConfig, StateMachineEvent } from './stateDefinitions'; // RNGH: patch
import { PressableStateMachine } from 'react-native-gesture-handler/src/components/Pressable/StateMachine';

const DEFAULT_LONG_PRESS_DURATION = 500;
const IS_TEST_ENV = isTestEnv();
type TimeoutHandle = ReturnType<typeof setTimeout>;

let IS_FABRIC: null | boolean = null;

function getRequireToFailDelayMs(relation: RelationPropType | undefined) {
  if (!relation) {
    return 0;
  }

  const gestures = Array.isArray(relation) ? relation : [relation];

  return gestures.reduce((delay, gesture) => {
    const candidate = gesture as {
      handlerName?: string;
      config?: {
        numberOfTaps?: number;
        maxDelayMs?: number;
        minDurationMs?: number;
      };
    };

    if (candidate.handlerName === 'TapGestureHandler') {
      const taps = candidate.config?.numberOfTaps ?? 1;
      if (taps > 1) {
        return Math.max(delay, candidate.config?.maxDelayMs ?? 200);
      }
    }

    if (candidate.handlerName === 'LongPressGestureHandler') {
      return Math.max(delay, candidate.config?.minDurationMs ?? 500);
    }

    return delay;
  }, 0);
}

const Pressable = (props: PressableProps) => {
  const isHarmony = (Platform.OS as string) === 'harmony';
  const {
    testOnly_pressed,
    hitSlop,
    pressRetentionOffset,
    //delayHoverIn,
    //delayHoverOut,
    delayLongPress,
    unstable_pressDelay,
    //onHoverIn,
    //onHoverOut,
    onPress,
    onPressIn,
    onPressOut,
    onLongPress,
    onLayout,
    style,
    children,
    android_disableSound,
    android_ripple,
    disabled,
    accessible,
    cancelable,
    simultaneousWithExternalGesture,
    requireExternalGestureToFail,
    blocksExternalGesture,
    ...remainingProps
  } = props;

  const relationProps = {
    simultaneousWithExternalGesture,
    requireExternalGestureToFail,
    blocksExternalGesture,
  };

  const [pressedState, setPressedState] = useState(testOnly_pressed ?? false);

  const longPressTimeoutRef = useRef<TimeoutHandle | null>(null);
  const pressDelayTimeoutRef = useRef<TimeoutHandle | null>(null);
  const pendingDirectPressTimeoutRef = useRef<TimeoutHandle | null>(null);
  const isOnPressAllowed = useRef<boolean>(true);
  const isCurrentlyPressed = useRef<boolean>(false);
  const didInterruptPendingDirectPressRef = useRef<boolean>(false);
  const latestTouchEventRef = useRef<PressableEvent | null>(null);
  const dimensions = useRef<PressableDimensions>({ width: 0, height: 0 });
  const shouldUseDirectPressLifecycle =
    isHarmony &&
    (Array.isArray(requireExternalGestureToFail)
      ? requireExternalGestureToFail.length > 0
      : requireExternalGestureToFail != null);
  const directPressDelayMs = useMemo(
    () =>
      shouldUseDirectPressLifecycle
        ? getRequireToFailDelayMs(requireExternalGestureToFail)
        : 0,
    [requireExternalGestureToFail, shouldUseDirectPressLifecycle]
  );

  const normalizedHitSlop: Insets = useMemo(
    () =>
      typeof hitSlop === 'number' ? numberAsInset(hitSlop) : (hitSlop ?? {}),
    [hitSlop]
  );

  const normalizedPressRetentionOffset: Insets = useMemo(
    () =>
      typeof pressRetentionOffset === 'number'
        ? numberAsInset(pressRetentionOffset)
        : (pressRetentionOffset ?? {}),
    [pressRetentionOffset]
  );

  const appliedHitSlop = addInsets(
    normalizedHitSlop,
    normalizedPressRetentionOffset
  );

  const cancelLongPress = useCallback(() => {
    if (longPressTimeoutRef.current) {
      clearTimeout(longPressTimeoutRef.current);
      longPressTimeoutRef.current = null;
      isOnPressAllowed.current = true;
    }
  }, []);

  const cancelDelayedPress = useCallback(() => {
    if (pressDelayTimeoutRef.current) {
      clearTimeout(pressDelayTimeoutRef.current);
      pressDelayTimeoutRef.current = null;
    }
  }, []);

  const clearPendingDirectPress = useCallback(() => {
    if (pendingDirectPressTimeoutRef.current) {
      clearTimeout(pendingDirectPressTimeoutRef.current);
      pendingDirectPressTimeoutRef.current = null;
    }
    didInterruptPendingDirectPressRef.current = false;
  }, []);

  const startLongPress = useCallback(
    (event: PressableEvent) => {
      if (onLongPress) {
        cancelLongPress();
        longPressTimeoutRef.current = setTimeout(() => {
          isOnPressAllowed.current = false;
          onLongPress(event);
        }, delayLongPress ?? DEFAULT_LONG_PRESS_DURATION);
      }
    },
    [onLongPress, cancelLongPress, delayLongPress]
  );

  const innerHandlePressIn = useCallback(
    (event: PressableEvent) => {
      onPressIn?.(event);
      startLongPress(event);
      setPressedState(true);
      if (pressDelayTimeoutRef.current) {
        clearTimeout(pressDelayTimeoutRef.current);
        pressDelayTimeoutRef.current = null;
      }
    },
    [onPressIn, startLongPress]
  );

  const handleFinalize = useCallback(() => {
    isCurrentlyPressed.current = false;
    latestTouchEventRef.current = null;
    clearPendingDirectPress();
    cancelLongPress();
    cancelDelayedPress();
    setPressedState(false);
  }, [cancelDelayedPress, cancelLongPress, clearPendingDirectPress]);

  const handlePressIn = useCallback(
    (event: PressableEvent) => {
      if (
        !isTouchWithinInset(
          dimensions.current,
          normalizedHitSlop,
          event.nativeEvent.changedTouches.at(-1)
        )
      ) {
        // Ignoring pressIn within pressRetentionOffset
        return;
      }

      isCurrentlyPressed.current = true;
      if (unstable_pressDelay) {
        pressDelayTimeoutRef.current = setTimeout(() => {
          innerHandlePressIn(event);
        }, unstable_pressDelay);
      } else {
        innerHandlePressIn(event);
      }
    },
    [innerHandlePressIn, normalizedHitSlop, unstable_pressDelay]
  );

  const handlePressOut = useCallback(
    (event: PressableEvent, success: boolean = true) => {
      if (!isCurrentlyPressed.current) {
        // Some prop configurations may lead to handlePressOut being called mutliple times.
        return;
      }

      isCurrentlyPressed.current = false;

      if (pressDelayTimeoutRef.current) {
        innerHandlePressIn(event);
      }

      onPressOut?.(event);

      if (isOnPressAllowed.current && success) {
        onPress?.(event);
      }

      handleFinalize();
    },
    [handleFinalize, innerHandlePressIn, onPress, onPressOut]
  );

  const finalizeDirectPressLifecycle = useCallback(
    (success: boolean) => {
      const latestTouchEvent = latestTouchEventRef.current;

      if (!latestTouchEvent) {
        handleFinalize();
        return;
      }

      handlePressOut(latestTouchEvent, success);
    },
    [handleFinalize, handlePressOut]
  );

  const stateMachine = useMemo(() => new PressableStateMachine(), []);

  useEffect(() => {
    const configuration = getStatesConfig(handlePressIn, handlePressOut);
    stateMachine.setStates(configuration);
  }, [handlePressIn, handlePressOut, stateMachine]);

  //const hoverInTimeout = useRef<number | null>(null);
  //const hoverOutTimeout = useRef<number | null>(null);

  //const hoverGesture = useMemo(
  //  () =>
  //    Gesture.Hover()
  //      .manualActivation(true) // Prevents Hover blocking Gesture.Native() on web
  //      .cancelsTouchesInView(false)
  //      .onBegin((event) => {
  //        if (hoverOutTimeout.current) {
  //          clearTimeout(hoverOutTimeout.current);
  //        }
  //        if (delayHoverIn) {
  //          hoverInTimeout.current = setTimeout(
  //            () => onHoverIn?.(gestureToPressableEvent(event)),
  //            delayHoverIn
  //          );
  //          return;
  //        }
  //        onHoverIn?.(gestureToPressableEvent(event));
  //      })
  //      .onFinalize((event) => {
  //        if (hoverInTimeout.current) {
  //          clearTimeout(hoverInTimeout.current);
  //        }
  //        if (delayHoverOut) {
  //          hoverOutTimeout.current = setTimeout(
  //            () => onHoverOut?.(gestureToPressableEvent(event)),
  //            delayHoverOut
  //          );
  //          return;
  //        }
  //        onHoverOut?.(gestureToPressableEvent(event));
  //      }),
  //  [delayHoverIn, delayHoverOut, onHoverIn, onHoverOut]
  //);

  const pressAndTouchGesture = useMemo(
    () =>
      Gesture.LongPress()
        .minDuration(Platform.OS === 'web' ? 0 : INT32_MAX) // Long press handles finalize on web, thus it must activate right away
        .maxDistance(INT32_MAX) // Stops long press from cancelling on touch move
        .cancelsTouchesInView(false)
        .onTouchesDown((event) => {
          const pressableEvent = gestureTouchToPressableEvent(event);
          latestTouchEventRef.current = pressableEvent;

          if (shouldUseDirectPressLifecycle) {
            if (pendingDirectPressTimeoutRef.current) {
              clearTimeout(pendingDirectPressTimeoutRef.current);
              pendingDirectPressTimeoutRef.current = null;
              didInterruptPendingDirectPressRef.current = true;
            }
            if (!isCurrentlyPressed.current) {
              handlePressIn(pressableEvent);
            }
            return;
          }

          stateMachine.handleEvent(
            StateMachineEvent.LONG_PRESS_TOUCHES_DOWN,
            pressableEvent
          );
        })
        .onTouchesUp(() => {
          if (Platform.OS === 'android') {
            // Prevents potential soft-locks
            stateMachine.reset();
            handleFinalize();
          }
        })
        .onTouchesCancelled((event) => {
          if (cancelable === false) return; // RNOH patch: cancelable=false 时忽略取消事件
          const pressableEvent = gestureTouchToPressableEvent(event);
          stateMachine.reset();
          handlePressOut(pressableEvent, false);
        })
        .onFinalize((_event, success) => {
          if (Platform.OS === 'web') {
            if (success) {
              stateMachine.handleEvent(StateMachineEvent.FINALIZE);
            } else {
              stateMachine.handleEvent(StateMachineEvent.CANCEL);
            }
            handleFinalize();
          }
        }),
    [
      stateMachine,
      handleFinalize,
      handlePressIn,
      handlePressOut,
      cancelable,
      shouldUseDirectPressLifecycle,
    ]
  );

  // RNButton is placed inside ButtonGesture to enable Android's ripple and to capture non-propagating events
  const buttonGesture = useMemo(
    () =>
      Gesture.Native()
        .onTouchesCancelled((event) => {
          if (Platform.OS !== 'macos' && Platform.OS !== 'web') {
            if (cancelable === false) return; // RNOH patch: cancelable=false 时忽略取消事件
            // On MacOS cancel occurs in middle of gesture
            // On Web cancel occurs on mouse move, which is unwanted
            const pressableEvent = gestureTouchToPressableEvent(event);
            stateMachine.reset();
            handlePressOut(pressableEvent, false);
          }
        })
        .onBegin(() => {
          if (shouldUseDirectPressLifecycle) {
            return;
          }
          stateMachine.handleEvent(StateMachineEvent.NATIVE_BEGIN);
        })
        .onStart(() => {
          if (shouldUseDirectPressLifecycle) {
            return;
          }
          if (Platform.OS !== 'android') {
            // Gesture.Native().onStart() is broken with Android + hitSlop
            stateMachine.handleEvent(StateMachineEvent.NATIVE_START);
          }
        })
        .onFinalize((_event, success) => {
          if (Platform.OS !== 'web') {
            if (shouldUseDirectPressLifecycle) {
              const shouldSucceed = success || cancelable === false;

              if (!shouldSucceed) {
                finalizeDirectPressLifecycle(false);
                return;
              }

              if (didInterruptPendingDirectPressRef.current) {
                didInterruptPendingDirectPressRef.current = false;
                finalizeDirectPressLifecycle(false);
                return;
              }

              if (directPressDelayMs > 0) {
                pendingDirectPressTimeoutRef.current = setTimeout(() => {
                  pendingDirectPressTimeoutRef.current = null;
                  finalizeDirectPressLifecycle(true);
                }, directPressDelayMs);
                return;
              }

              finalizeDirectPressLifecycle(true);
              return;
            }
            // On Web we use LongPress().onFinalize() instead of Native().onFinalize(),
            // as Native cancels on mouse move, and LongPress does not.
            // RNOH patch: cancelable=false 时，将外部取消视为正常完成
            if (success || cancelable === false) {
              stateMachine.handleEvent(StateMachineEvent.FINALIZE);
            } else {
              stateMachine.handleEvent(StateMachineEvent.CANCEL);
            }

            if (Platform.OS !== 'ios') {
              handleFinalize();
            }
          }
        }),
    [
      stateMachine,
      handlePressOut,
      handleFinalize,
      cancelable,
      directPressDelayMs,
      finalizeDirectPressLifecycle,
      shouldUseDirectPressLifecycle,
    ]
  );

  const isPressableEnabled = disabled !== true;

  //const gestures = [buttonGesture, pressAndTouchGesture, hoverGesture];
  const gestures = [buttonGesture, pressAndTouchGesture];

  for (const gesture of gestures) {
    gesture.enabled(isPressableEnabled);
    gesture.runOnJS(true);
    gesture.hitSlop(appliedHitSlop);

    Object.entries(relationProps).forEach(([relationName, relation]) => {
      applyRelationProp(
        gesture,
        relationName as RelationPropName,
        relation as RelationPropType
      );
    });
  }

  const gesture = Gesture.Simultaneous(...gestures);

  // `cursor: 'pointer'` on `RNButton` crashes iOS
  const pointerStyle: StyleProp<ViewStyle> =
    Platform.OS === 'web' ? { cursor: 'pointer' } : {};

  const styleProp =
    typeof style === 'function' ? style({ pressed: pressedState }) : style;

  const childrenProp =
    typeof children === 'function'
      ? children({ pressed: pressedState })
      : children;

  const rippleColor = useMemo(() => {
    if (IS_FABRIC === null) {
      IS_FABRIC = isFabric();
    }

    const defaultRippleColor = android_ripple ? undefined : 'transparent';
    const unprocessedRippleColor = android_ripple?.color ?? defaultRippleColor;
    return IS_FABRIC
      ? unprocessedRippleColor
      : processColor(unprocessedRippleColor);
  }, [android_ripple]);

  const setDimensions = useCallback(
    (event: LayoutChangeEvent) => {
      onLayout?.(event);
      dimensions.current = event.nativeEvent.layout;
    },
    [onLayout]
  );

  return (
    <GestureDetector gesture={gesture}>
      <NativeButton
        {...remainingProps}
        onLayout={setDimensions}
        accessible={accessible !== false}
        hitSlop={appliedHitSlop}
        enabled={isPressableEnabled}
        touchSoundDisabled={android_disableSound ?? undefined}
        rippleColor={rippleColor}
        rippleRadius={android_ripple?.radius ?? undefined}
        style={[pointerStyle, styleProp]}
        testOnly_onPress={IS_TEST_ENV ? onPress : undefined}
        testOnly_onPressIn={IS_TEST_ENV ? onPressIn : undefined}
        testOnly_onPressOut={IS_TEST_ENV ? onPressOut : undefined}
        testOnly_onLongPress={IS_TEST_ENV ? onLongPress : undefined}>
        {childrenProp}
        {__DEV__ ? (
          <PressabilityDebugView color="red" hitSlop={normalizedHitSlop} />
        ) : null}
      </NativeButton>
    </GestureDetector>
  );
};

export default Pressable;
