/*
 * Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
 * Use of this source code is governed by a MIT license that can be
 * found in the LICENSE file.
 */
import { Platform } from 'react-native';

type PlatformConstants = {
  forceTouchAvailable: boolean;
};

// Patched this line because original failed in bridgeless
export default Platform.constants as PlatformConstants;
