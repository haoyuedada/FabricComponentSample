# @react-native-ohos/react-native-pager-view

This project is based on [react-native-pager-view@v7.0.2](https://github.com/callstack/react-native-pager-view/releases/tag/v7.0.2)

## Documentation

[中文](https://gitee.com/react-native-oh-library/usage-docs/blob/master/zh-cn/react-native-pager-view.md)

[English](https://gitee.com/react-native-oh-library/usage-docs/blob/master/en/react-native-pager-view.md)


## License

This library is licensed under [The MIT License (MIT)](https://github.com/react-native-oh-library/react-native-pager-view/blob/sig/LICENSE).

