/**
 * MIT License
 *
 * Copyright (C) 2025 Huawei Device Co., Ltd.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
import type * as React from 'react';
import type { HostComponent, ViewProps } from 'react-native';
import type { DirectEventHandler, Double, Int32, WithDefault } from 'react-native/Libraries/Types/CodegenTypes';
export type OnPageScrollEventData = Readonly<{
    position: Double;
    offset: Double;
}>;
export type OnPageSelectedEventData = Readonly<{
    position: Double;
}>;
export type OnPageScrollStateChangedEventData = Readonly<{
    pageScrollState: 'idle' | 'dragging' | 'settling';
}>;
export interface NativeProps extends ViewProps {
    scrollEnabled?: WithDefault<boolean, true>;
    layoutDirection?: WithDefault<'ltr' | 'rtl', 'ltr'>;
    initialPage?: Int32;
    orientation?: WithDefault<'horizontal' | 'vertical', 'horizontal'>;
    offscreenPageLimit?: Int32;
    pageMargin?: Int32;
    overScrollMode?: WithDefault<'auto' | 'always' | 'never', 'auto'>;
    overdrag?: WithDefault<boolean, false>;
    keyboardDismissMode?: WithDefault<'none' | 'on-drag', 'none'>;
    onPageScroll?: DirectEventHandler<OnPageScrollEventData>;
    onPageSelected?: DirectEventHandler<OnPageSelectedEventData>;
    onPageScrollStateChanged?: DirectEventHandler<OnPageScrollStateChangedEventData>;
}
type PagerViewViewType = HostComponent<NativeProps>;
export interface NativeCommands {
    setPage: (viewRef: React.ElementRef<PagerViewViewType>, selectedPage: Int32) => void;
    setPageWithoutAnimation: (viewRef: React.ElementRef<PagerViewViewType>, selectedPage: Int32) => void;
    setScrollEnabledImperatively: (viewRef: React.ElementRef<PagerViewViewType>, scrollEnabled: boolean) => void;
}
export declare const Commands: NativeCommands;
declare const _default: HostComponent<NativeProps>;
export default _default;
//# sourceMappingURL=PagerViewNativeComponent.d.ts.map