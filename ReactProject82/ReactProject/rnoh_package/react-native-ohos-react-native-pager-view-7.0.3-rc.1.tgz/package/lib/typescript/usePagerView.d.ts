/// <reference types="react" />
/**
 * MIT License
 *
 * Copyright (C) 2025 Huawei Device Co., Ltd.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
import type * as ReactNative from 'react-native';
import type { OnPageScrollStateChangedEventData as PageScrollStateChangedNativeEventData } from './PagerViewNativeComponent';
type PageScrollStateChangedNativeEvent = ReactNative.NativeSyntheticEvent<PageScrollStateChangedNativeEventData>;
import { PagerView } from './PagerView';
import { Animated } from 'react-native';
export type UsePagerViewProps = ReturnType<typeof usePagerView>;
type UsePagerViewParams = {
    pagesAmount: number;
};
export declare function usePagerView({ pagesAmount }?: UsePagerViewParams): {
    ref: import("react").RefObject<PagerView | null>;
    activePage: number;
    isAnimated: boolean;
    pages: number[];
    scrollState: string;
    scrollEnabled: boolean;
    progress: {
        position: number;
        offset: number;
    };
    overdragEnabled: boolean;
    setPage: (page: number) => void;
    addPage: () => void;
    removePage: () => void;
    toggleScroll: () => void;
    toggleAnimation: () => void;
    setProgress: import("react").Dispatch<import("react").SetStateAction<{
        position: number;
        offset: number;
    }>>;
    onPageScroll: (...args: any[]) => void;
    onPageSelected: (...args: any[]) => void;
    onPageScrollStateChanged: (e: PageScrollStateChangedNativeEvent) => void;
    toggleOverdrag: () => void;
    AnimatedPagerView: Animated.AnimatedComponent<typeof PagerView>;
    PagerView: typeof PagerView;
};
export {};
//# sourceMappingURL=usePagerView.d.ts.map