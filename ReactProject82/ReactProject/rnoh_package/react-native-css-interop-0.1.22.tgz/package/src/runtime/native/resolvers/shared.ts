export const ShorthandSymbol = Symbol();
